#!/bin/bash
# November 2018

# This Script will index the given reference genome with BWA and SAMtools and generate
# a "mapped" folder in /BEARCAVE/.

# This script should be run from /BEARCAVE/scripts
# Example command line: sh index_ref.sh $1
# $1 = 	Fasta file containing the reference genome, 
# 		e.g. ../refgenomes/PolarBear_mt/polarbear_mt.fasta.gz

folder=$(echo $1 | rev | cut -d'/' -f2 | rev)

gunzip $1 2> /dev/null

fasta=$(echo $1 | sed 's/.gz$//' )

rename .fasta .fa $fasta

fa=$(echo $fasta | sed 's/.fasta$/.fa/')

../software/miniconda3/bin/bwa index $fa
../software/miniconda3/bin/samtools faidx $fa
chmod 550 ../refgenomes/$folder/
chmod 440 ../refgenomes/$folder/*

mkdir -p ../mapped$folder
mkdir -p ../mapped$folder/$folder_logs
chmod 770 -R ../mapped$folder