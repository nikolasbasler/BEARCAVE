#!/bin/bash
# November 2018

# This Script will index the given reference genome with BWA and SAMtools and generate
# a "mapped" folder in /BEARCAVE/.

# This script should be run from /BEARCAVE/scripts
# Example command line: sh index_ref.sh $1
# $1 = Name of the reference genome (folder name in /refgenomes/)

../software/miniconda3/bin/bwa index ../refgenomes/$1/*.fa
../software/miniconda3/bin/samtools faidx ../refgenomes/$1/*.fa
chmod 550 ../refgenomes/$1/
chmod 440 ../refgenomes/$1/*

mkdir ../mapped$1
mkdir ../mapped$1/$1_logs
chmod 770 -R ../mapped$1